# 📰 Fake News Detector

A simple **Machine Learning** project to detect whether a news article is **Fake** or **Real**. This project uses **Python**, **Scikit-learn**, and **Streamlit** to provide an interactive web interface.

## 🔹 Features
- Classifies news articles as **Fake** or **Real**.
- Easy-to-use **web interface** using Streamlit.
- Uses **TF-IDF Vectorizer** and **Logistic Regression** for prediction.
- Fully ready for student projects and learning purposes.

## 🛠️ Tech Stack
- Python 3.x
- Pandas
- Scikit-learn
- Streamlit
- Joblib (for saving/loading models)

## 🚀 How to Run
1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/fake-news-detector.git
cd fake-news-detector
```
2. Install dependencies
```bash
pip install -r requirements.txt
```
3. Train the model
```bash
python train_model.py
```
4. Run the Streamlit app
```bash
streamlit run app.py
```
Open the URL shown in the terminal (usually http://localhost:8501) to start using the app.

## 📊 Dataset
- Use the **Fake and Real News Dataset** from Kaggle: https://www.kaggle.com/datasets/clmentbisaillon/fake-and-real-news-dataset
- CSV should have columns: `text` (news content) and `label` (FAKE/REAL).

## 📌 Author
- Student Project by [Your Name]
- Built with ❤️ using Python, Scikit-learn, and Streamlit.