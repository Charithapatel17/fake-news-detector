import streamlit as st
import joblib

st.set_page_config(page_title="Fake News Detector", page_icon="📰")
st.title("📰 Fake News Detector")
st.write("Enter a news headline or paragraph to check if it is **Fake** or **Real** using Machine Learning.")

@st.cache_resource
def load_files():
    model = joblib.load("model.pkl")
    vectorizer = joblib.load("vectorizer.pkl")
    return model, vectorizer

model, vectorizer = load_files()
news_text = st.text_area("🧾 Enter news content here:")

if st.button("Check"):
    if not news_text.strip():
        st.warning("Please enter some text.")
    else:
        transformed = vectorizer.transform([news_text])
        prediction = model.predict(transformed)[0]
        if prediction.lower() == "fake":
            st.error("🚫 This news appears to be **FAKE**.")
        else:
            st.success("✅ This news appears to be **REAL**.")

st.markdown("---")
st.caption("Student Project | Streamlit + Machine Learning")